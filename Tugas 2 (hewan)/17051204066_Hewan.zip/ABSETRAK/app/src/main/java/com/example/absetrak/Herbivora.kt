package com.example.absetrak

interface Herbivora {
    fun displayMakan()

    companion object {
        val jenisH = "Herbivora"
        val makananH = "Tumbuhan"
    }
}
