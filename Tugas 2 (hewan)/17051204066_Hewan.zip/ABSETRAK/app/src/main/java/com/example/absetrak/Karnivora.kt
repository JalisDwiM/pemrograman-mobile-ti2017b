package com.example.absetrak

interface Karnivora {
    fun displayMakan()

    companion object {
        val jenisK = "Karnivora"
        val makananK = "Daging"
    }
}
