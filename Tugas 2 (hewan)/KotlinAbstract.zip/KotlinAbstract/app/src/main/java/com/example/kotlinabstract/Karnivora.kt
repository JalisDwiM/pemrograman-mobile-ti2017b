package com.example.kotlinabstract

interface Karnivora {
    fun displayMakan()

    companion object {
        val jenisK = "Karnivora"
        val makananK = "Daging"
    }
}
