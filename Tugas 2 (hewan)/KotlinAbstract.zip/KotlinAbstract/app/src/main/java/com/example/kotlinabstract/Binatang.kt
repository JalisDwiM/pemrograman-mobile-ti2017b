package com.example.kotlinabstract

abstract class Binatang(var nama: String, var kaki: Int) {
    open fun displayBinatang() {
        println("Nama: $nama")
        println("Jumlah Kaki: $kaki")
    }
}