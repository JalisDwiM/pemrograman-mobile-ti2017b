package com.example.kotlinabstract

object Semua {
    var namahw = ""
    var jmlk = 0
    var suar = ""
    var wb = ""
    var mk = ""
    var jenishw = ""
    fun displayk() {
        val k = Kucing("Kucing", 4, "Meong meong", "Coklat")
        namahw = k.nama
        jmlk = k.kaki
        suar = k.suara
        wb = k.warnaBulu
        jenishw = Karnivora.jenisK
        mk = Karnivora.makananK
    }
    fun displayg() {
        val g = Gajah("Gajah", 4, "Toeettoeet", "Abu-abu")
        namahw = g.nama
        jmlk = g.kaki
        suar = g.suara
        wb = g.warnaBulu
        jenishw = Herbivora.jenisH
        mk = Herbivora.makananH
    }

    fun displayb() {
        val b = Beruang("Beruang", 4, "Grrrrrrraaaa", "Coklat")
        namahw = b.nama
        jmlk = b.kaki
        suar = b.suara
        wb = b.warnaBulu
        jenishw = Karnivora.jenisK+" "+Herbivora.jenisH
        mk = Karnivora.makananK+" "+Herbivora.makananH
    }
}