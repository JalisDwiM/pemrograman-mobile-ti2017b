package com.example.kotlinabstract

class Gajah(nama: String, jmlKaki: Int,  val suara: String,  val warnaBulu: String) :
    Binatang(nama, jmlKaki), Herbivora {
    override fun displayMakan() {
        println("Jenis: " + Herbivora.jenisH)
        println("Makanan: " + Herbivora.makananH)
    }

    override fun displayBinatang() {
        println("Nama: $nama")
        println("Jumlah Kaki: $kaki")
    }

    fun displayData() {
        displayMakan()
        displayBinatang()
        println("Suara: $suara")
        println("Warna Bulu: $warnaBulu")
    }
}