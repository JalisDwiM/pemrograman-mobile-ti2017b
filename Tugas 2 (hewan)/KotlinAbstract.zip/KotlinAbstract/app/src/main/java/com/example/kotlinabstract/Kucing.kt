package com.example.kotlinabstract

class Kucing(nama: String, jmlKaki: Int,  val suara: String,  val warnaBulu: String) :
    Binatang(nama, jmlKaki), Karnivora {
    override fun displayMakan() {
        println("Jenis: " + Karnivora.jenisK)
        println("Makanan: " + Karnivora.makananK)
    }

    override fun displayBinatang() {
        println("Nama: $nama")
        println("Jumlah Kaki: $kaki")
    }

    fun displayData() {
        displayMakan()
        displayBinatang()
        println("Suara: $suara")
        println("Warna Bulu: $warnaBulu")
    }
}
