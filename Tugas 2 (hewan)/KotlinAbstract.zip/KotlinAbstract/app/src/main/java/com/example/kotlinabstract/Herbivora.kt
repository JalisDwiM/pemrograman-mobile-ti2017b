package com.example.kotlinabstract

interface Herbivora {
    fun displayMakan()

    companion object {
        val jenisH = "Herbivora"
        val makananH = "Tumbuhan"
    }
}
