package com.example.kalkulatorpasar

import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import android.os.Bundle

import com.example.kalkulatorpasar.databinding.ActivityMainBinding

import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private var binding: ActivityMainBinding? = null

    private var CURRENT_ACTION: Char = ' '

    private var valueOne = java.lang.Double.NaN
    private var valueTwo: Double = 0.toDouble()

    private var decimalFormat: DecimalFormat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        decimalFormat = DecimalFormat("#.##########")

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding!!.buttonDot.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + ".") }

        binding!!.buttonZero.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "0") }

        binding!!.buttonOne.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "1") }

        binding!!.buttonTwo.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "2") }

        binding!!.buttonThree.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "3") }

        binding!!.buttonFour.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "4") }

        binding!!.buttonFive.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "5") }

        binding!!.buttonSix.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "6") }

        binding!!.buttonSeven.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "7") }

        binding!!.buttonEight.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "8") }

        binding!!.buttonNine.setOnClickListener { binding!!.editText.setText(binding!!.editText.text.toString() + "9") }

        binding!!.buttonAdd.setOnClickListener {
            computeCalculation()
            CURRENT_ACTION = ADDITION
            binding!!.infoTextView.text = decimalFormat!!.format(valueOne) + "+"
            binding!!.editText.text = null
        }

        binding!!.buttonSubtract.setOnClickListener {
            computeCalculation()
            CURRENT_ACTION = SUBTRACTION
            binding!!.infoTextView.text = decimalFormat!!.format(valueOne) + "-"
            binding!!.editText.text = null
        }

        binding!!.buttonMultiply.setOnClickListener {
            computeCalculation()
            CURRENT_ACTION = MULTIPLICATION
            binding!!.infoTextView.text = decimalFormat!!.format(valueOne) + "*"
            binding!!.editText.text = null
        }

        binding!!.buttonDivide.setOnClickListener {
            computeCalculation()
            CURRENT_ACTION = DIVISION
            binding!!.infoTextView.text = decimalFormat!!.format(valueOne) + "/"
            binding!!.editText.text = null
        }

        binding!!.buttonEqual.setOnClickListener {
            computeCalculation()
            binding!!.infoTextView.text = binding!!.infoTextView.text.toString() + decimalFormat!!.format(valueTwo) + " = " + decimalFormat!!.format(valueOne)
            valueOne = java.lang.Double.NaN
            CURRENT_ACTION = '0'
        }

        binding!!.buttonClear.setOnClickListener {
            if (binding!!.editText.text.length > 0) {
                val currentText = binding!!.editText.text
                binding!!.editText.setText(currentText.subSequence(0, currentText.length - 1))
            } else {
                valueOne = java.lang.Double.NaN
                valueTwo = java.lang.Double.NaN
                binding!!.editText.setText("")
                binding!!.infoTextView.text = ""
            }
        }
    }

    private fun computeCalculation() {
        if (!java.lang.Double.isNaN(valueOne)) {
            valueTwo = java.lang.Double.parseDouble(binding!!.editText.text.toString())
            binding!!.editText.text = null

            if (CURRENT_ACTION == ADDITION)
                valueOne = this.valueOne + valueTwo
            else if (CURRENT_ACTION == SUBTRACTION)
                valueOne = this.valueOne - valueTwo
            else if (CURRENT_ACTION == MULTIPLICATION)
                valueOne = this.valueOne * valueTwo
            else if (CURRENT_ACTION == DIVISION)
                valueOne = this.valueOne / valueTwo
        } else {
            try {
                valueOne = java.lang.Double.parseDouble(binding!!.editText.text.toString())
            } catch (e: Exception) {
            }

        }
    }

    companion object {

        private val ADDITION = '+'
        private val SUBTRACTION = '-'
        private val MULTIPLICATION = '*'
        private val DIVISION = '/'
    }
}
